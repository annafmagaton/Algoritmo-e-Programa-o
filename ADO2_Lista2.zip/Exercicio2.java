/* 
Exercício 2: Desenvolver um programa que leia um vetor X de 10 
posições de inteiros. Substitua a seguir, os valores negativos do 
vetor X por 1. Em seguida, apresente o vetor X. 
Discentes: Anna Paula F. Magaton, Byanca Moraes e Denise Melo
*/

import java.util.Arrays;

class Exercicio2 {

    public static void main(String[] args) {
        int v[] = { 10, 20, -30, 40, -50, 60, -70, 80, 90, 100 };

        for (int i = 0; i < v.length; i++) {
            if (v[i] < 0) {
                v[i] = 1;
            }
        }

        System.out.println(Arrays.toString(v));
    }

}