/* 
Exercício 1: Desenvolver uma função que receba dois números inteiros: 
um valor A e um valor N. A função deve retornar a soma dos N números a 
partir de A (inclusive). Se N for negativo ou zero, a função deve 
retornar -1. A função main deve ler dois valores inteiros (para A e N), 
chamar a função criada e apresentar na tela o dado retornado pela função. 
Discentes: Anna Paula F. Magaton, Byanca Moraes e Denise Melo.
*/

import java.util.Scanner;

class Exercicio1 {
  public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    System.out.print("Digite um número inteiro A: ");
    int a = teclado.nextInt();
    System.out.print("Digite um número inteiro N: ");
    int n = teclado.nextInt();
    int x = somaNumero(a, n);

    System.out.printf("Resultado: %d\n", x);
  }

  public static int somaNumero(int a, int n) {
    if (n <= 0) {
      return -1;
    }

    int soma = 0;

    for (int i = a; i <= n; i++) {
      soma += i;
    }

    return soma;
  }

}