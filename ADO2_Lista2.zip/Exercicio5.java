/* 
Exercício 5: Desenvolver uma função que recebe dois vetores inteiros A[] e B[], 
em seguida, a sua função efetua a INTERSECÇÃO, entre os vetores, ou seja, os 
elementos em comum entre os dois vetores, ao final sua função retorna uma String 
com a resposta. Os vetores dados não possuem valores duplicados e não estão ordenados. 
Discentes: Anna Paula F. Magaton, Byanca Moraes e Denise Melo
*/

import java.util.Arrays;

class Exercicio5 {
    public static void main(String[] args) {
        int[] vetorA = { 5, 9, 2, 4, 11, 3, 8, 20 };
        int[] vetorB = { 4, 8, 2, 5, 7, 11, 15 };
        String retorno = interseccao(vetorA, vetorB); // chamando função no main
        System.out.println(retorno); // imprimindo a intersecção
    }

    static String interseccao(int[] vetorA, int[] vetorB) {
        int[] vetorAux = new int[vetorA.length + vetorB.length];// receber o tamanho dos vetores, posições e seus
                                                                // valores
        int d = 0; // posição para auxiliar
        for (int i = 0; i < vetorA.length; i++) {
            for (int j = 0; j < vetorB.length; j++) {
                if (vetorA[i] == vetorB[j])
                    vetorAux[d++] = vetorA[i];// auxiliar para receber valores de vetorA[i] e não perde-los
            }
        }

        int[] vetorC = new int[d];
        for (int i = 0; i < d; i++)
            vetorC[i] = vetorAux[i];// auxiliar para receber valores de vetores com intersecção
        return Arrays.toString(vetorC);
    }
}