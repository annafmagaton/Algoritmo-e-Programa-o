/* 
Exercício 3: Desenvolver um programa que leia um vetor de 16 posições 
de valores inteiros e troque os 8 primeiros valores pelos 8 últimos valores 
e vice-versa. Ao final apresentar na tela os dados do vetor obtido. 
Discentes: Anna Paula F. Magaton, Byanca Moraes e Denise Melo
*/

import java.util.Arrays;

class Exercicio3 {
    public static void main(String[] args) {

        int[] v = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
        int tam = v.length;
        for (int i = 0; i < tam / 2; i++) {
            int aux = v[i];
            int fim = (tam / 2) + i; // posição para aux
            v[i] = v[fim];
            v[fim] = aux; // aux para não perder valor
        }

        System.out.println(Arrays.toString(v));

    }
}