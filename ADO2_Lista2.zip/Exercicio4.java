/* 
Exercício 4: Um vetor é palíndromo se ele não se altera quando as posições 
dos componentes são invertidas. Por exemplo, o vetor v [] = {1, 3, 5, 2, 2, 5, 3, 1} 
é palíndromo. Desenvolver uma função que recebe por parâmetro um vetor de inteiros e 
retorna um vetor booleano indicando se o vetor é ou não palíndromo. 
Discentes: Anna Paula F. Magaton, Byanca Moraes e Denise Melo
*/

class Exercicio4 {
    public static void main(String[] args) {
        int v[] = { 1, 3, 5, 2, 3, 5, 3, 1 };

        boolean isPalindromo = palindromo(v);

        System.out.println(isPalindromo);
    }

    public static boolean palindromo(int v[]) {
        int tam = v.length;
        for (int i = 0; i < tam / 2; i++) {
            if (v[i] != v[tam - 1 - i]) {
                return false;
            }
        }
        return true;
    }
}